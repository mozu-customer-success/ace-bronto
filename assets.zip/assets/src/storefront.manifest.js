module.exports = {
  
  'saveContact': {
      actionName: 'http.storefront.routes',
      customFunction: require('./domains/storefront/saveContact')
  }
};
